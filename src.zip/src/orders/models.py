from django.db import models
from common.models import User, TimeStampMixin
from CartSystem.models import AddToCart
from Offers.models import Offer
from products.models import Product
from deliveryExecutive.models import DeliveryExecutive
from vendor.models import Vendor
from .utils import order_status_choice, payment_method, save_address_as, payment_status
import random, datetime



# Contact Address
class ContactAddress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=False, null=False)
    name = models.CharField("Full name", max_length=255, blank=False, null=False)
    contact_number = models.CharField("Mobile No", max_length=20, blank=False, null=False)
    postcode = models.CharField("Post/Zip-code", max_length=64, blank=True, null=True)
    address_line = models.CharField("Address", max_length=255,
                                    help_text=("Address (House No, Building, Street, Area)"), blank=False, null=True)
    locality = models.CharField("Locality/Town", max_length=255, )
    city = models.CharField("City/District", max_length=255, help_text= ("City/District"), blank=False, null=False)
    state = models.CharField("State", max_length=255, help_text= ("State"), blank=False, null=False)
    save_address_as = models.CharField("Save Address As", max_length= 200, choices=save_address_as, default="Home")
    is_default = models.BooleanField(default=False)
    map_lat = models.CharField("Map Lat", max_length=50, blank=False, null=False, default="0.0")
    map_lng = models.CharField("Map Lng", max_length=50, blank=False, null=False, default="0.0")

    class Meta:
        verbose_name_plural = 'Contact Address'


    def __str__(self):
        return str(("Name: {}, Address line: {}, Locality: {}, City: {}, State: {}, Post Code: {}").format(
            self.name, self.address_line, self.locality, self.city, self.state, self.postcode))


# OrderNumber
class OrderNumber(models.Model):
    order_number = models.CharField(max_length=25, unique=True, editable=False, blank=True, null=True)

    def __str__(self):
        return str(self.order_number)

    class Meta:
        """This model will not create any Database Table"""
        abstract = True

    def save(self, *args, **kwargs):
        if not self.order_number:
            self.order_number = self.po_id_generator()
            while OrderDetail.objects.filter(order_number=self.order_number).exists():
                self.order_number = self.po_id_generator()
        super(OrderNumber, self).save(*args, **kwargs)

    def po_id_generator(self):
        """if prev_order_number:
            prev_order_number += 1
            return prev_po_no"""
        return "ORD"+str(random.randint(2345678900, 99234567890))

# OrderDetail Model
class OrderDetail(TimeStampMixin, OrderNumber):
    user = models.ForeignKey(User, related_name="Customer", on_delete=models.CASCADE, blank=False, null=False)
    address = models.ForeignKey(ContactAddress,
                                related_name="ShippingAddress",
                                on_delete=models.PROTECT,
                                blank=False, null=False)
    price = models.DecimalField("Products Price", editable=False, blank=True, null=True, max_digits=12,
                                decimal_places=2, default=0.00)
    shipping_charge = models.DecimalField("Shipping Charges", editable=False, blank=True, null=True, max_digits=12,
                                          decimal_places=2, default=0.00)
    tax = models.DecimalField("Total Tax", editable=False, blank=True, null=True, max_digits=12, decimal_places=2,
                                    default=0.00)
    grand_total = models.DecimalField("Grand Total", editable=False, blank=True, null=True, max_digits=12,
                                      decimal_places=2, default=0.00)
    offer_code = models.CharField("Offer Code", max_length=20, blank=True, null=True, default="N/A")
    #offer_code = models.ForeignKey(Offer, related_name="Offers", on_delete=models.CASCADE, blank=True, null=True, default="---")
    offer_discount =  models.DecimalField("Discount Amount",
                                          max_digits=12, decimal_places=2,
                                        blank=True, null=True, default=0.00)
    payment_method = models.CharField(
        "Payment Methods", max_length=200, choices=payment_method, null=True, blank=False, default= "COD")
    payment_status = models.CharField(
        "Payment Status", max_length=50, choices=payment_status, null=True, blank=False,
                                      default="Pending")
    order_status = models.CharField("Order Status",
                                    max_length=100,
                                    choices=order_status_choice,
                                    blank=False, null=False, default= "Pending")
    delivery_exe = models.ForeignKey(DeliveryExecutive,
                                     related_name="Delivery_executive",
                                     on_delete=models.PROTECT, blank=True, null=True)


    def __str__(self):
        return str(self.order_number)


    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Order Details"



# OrderDetail Model
class OrderProductDetail(TimeStampMixin):
    order = models.ForeignKey(OrderDetail, related_name="Order", on_delete=models.CASCADE, blank=False, null=False)
    product = models.ForeignKey(Product, related_name="Product", on_delete=models.CASCADE, blank=False, null=False)
    price = models.DecimalField("Products Price", editable=False, blank=True, null=True, max_digits=12,
                                decimal_places=2,
                                default=0.00)
    quantity = models.PositiveIntegerField("Quantity", null=False, blank=False, default=1)
    total_price = models.DecimalField("Total Price", editable=False, blank=True, null=True, max_digits=12,
                                decimal_places=2,
                                default=0.00)
    def __str__(self):
        return str(self.order)


    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Order Product Details"

    def save(self, *args, **kwargs):
        self.price = self.product.price
        self.total_price = self.quantity * self.product.price
        super(OrderProductDetail, self).save(*args, **kwargs)

# Delivery Executive live data details model created here because the circular import problem
class DeliveryExeLiveData(TimeStampMixin):
    DeliveryExeLiveStatus = (
        ("active", "Active"),
        ("inactive", "Inactive"),
        ("intransit", "In Transit"),
    )
    delivery_exe = models.OneToOneField(DeliveryExecutive, on_delete=models.CASCADE, primary_key=False)
    live_map_lat = models.CharField("Map Lat", max_length=50, blank=False, null=False)
    live_map_lng = models.CharField("Map Lng", max_length=50, blank=False, null=False)
    live_oder = models.ForeignKey(OrderDetail, on_delete=models.CASCADE, blank=True, null=True)
    live_status = models.CharField("Live Status", max_length=20, choices=DeliveryExeLiveStatus, default="inactive")


    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = 'Delivery Exe. Live Data'

    def __str__(self):
        return str(self.delivery_exe)



class VendorOrderDetails(TimeStampMixin):

    statusChoice = (
        ("Waiting For Pickup", "Waiting For Pickup"),
        ("Picked Up", "Picked Up"),
        ("Delivered", "Delivered"),
    )

    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, blank=False, null=False)
    order = models.ForeignKey(OrderDetail, on_delete=models.CASCADE, blank=False, null=False)
    total_items = models.IntegerField("Total Items", default=0, blank=False, null=False)
    total_quantity = models.IntegerField("Total Quantity", default=0, blank=False, null=False)
    total_price = models.DecimalField("Total Price", max_digits=10, decimal_places=2, default=00.00, blank=False, null=False)
    total_tax = models.DecimalField("Total Tax", max_digits=10, decimal_places=2, default=00.00, blank=False, null=False)
    grand_total = models.DecimalField("Grand Total", max_digits=10, decimal_places=2, default=00.00, blank=True, null=False)
    order_status = models.CharField(max_length=50, choices=statusChoice, default="Waiting for Pickup", blank=False, null=False)
    
    
    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = 'Vendor Orders'

    def __str__(self):
        return str(self.order)