order_status_choice = (
    ("Pending", 'Pending'),
    ("Order Placed", 'Order Placed'),
    ("On The Way", 'On The Way'),
    ("Delivered", 'Delivered'),
    ("Cancelled", 'Cancelled'),
)


save_address_as = (
    ("Home", "Home"),
    ("Work", "Work"),
)



payment_method = (
        ("Razorpay", "Razorpay"),
        ("COD", "Cash On Delivery"),
)

payment_status = (
        ("Pending", "Pending"),
        ("Paid", "Paid"),

)

DeliveryCharges_Name = (
    ("free_delivery", "Free Delivery"),
    ("delivery_charges", "Delivery Charges"),
)

